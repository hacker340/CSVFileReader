/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csvfiletotable;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;

/**
 *
 * @author sri
 */
public class CSVFileToTable {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        Class.forName("com.mysql.jdbc.Driver");
        BufferedReader bReader = new BufferedReader(new FileReader("C:\\Users\\sri\\Desktop\\example.csv"));// location of file
        Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/sonno","root","root");
        String line;
        String[] s=bReader.readLine().split(","); //to read the headers
        
        Statement st = con.createStatement();
        DatabaseMetaData dbm = con.getMetaData();
        ResultSet tables = dbm.getTables(null, null, "students", null);
        if (tables.next()) {
            // Table exists
            System.out.println("Table name you entered already exists. So please enter the another name in program.");
        }
        else {
            // Table does not exist
            boolean b = st.execute("create table students("+s[0]+" int(3), "+s[1]+" varchar(20),"+s[2]+" varchar(20),"+s[3]+" varchar(20))");
            System.out.println("Table is created.");
            System.out.println("Data in the file:\n***********************");
            String sql = " INSERT INTO students(id,name,email,address) VALUES(?,?,?,?)";
            while((line=bReader.readLine())!=null){
                if(line!=null){
                    s = line.split(",");
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1,s[0]);
                     ps.setString(2,s[1]);
                     ps.setString(3,s[2]);
                     ps.setString(4,s[3]);
                     ps.execute();
                    System.out.println(s[0]+"\t"+s[1]+"\t"+s[2]+"\t"+s[3]);
                }
            }
            System.out.println("\nData in table\n************************ ");
            Statement stmt=  con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from students");
            while(rs.next())  
                System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getString(4));  
        
        }
        
        
        bReader.close();
        con.close();  
    }
    
}
